import oracledb
import getpass
import csv

"""Se definen las variables necesarias para lograr la conexión de Python con Oracle

    Returns:
        Si las credenciales ingresadas son correctas se ingresará a la base de datos con la cual
        se reqiera trabajar 
    """ 
p_username = "system"
pw = "0034"
p_password = pw
p_dns = "localhost/xe"
p_port = "1521"

con = oracledb.connect(user=p_username, password=p_password, dsn=p_dns, port=p_port)

# ------------------------CREACION PERSONA------------------------
"""Una vez conectada la base se procede a leer un archivo csv creado para la tabla de personas

    Returns:
        Si las credenciales ingresadas son correctas se vaa leer cada columna de acuerdo a la base de datos
        luego se define el número de columnas y una vez establecidos bien los parémtros se cargarán los datos
        del csv a la base de la tabla especificada en este caso persona
    """ 
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_PERSONA.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 2")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_PERSONA" VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga Persona---")
cur.close()

print("completed")"""

# ------------------------CREACION HIJO-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_HIJO.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 2")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_HIJO" VALUES (:1, :2, :3, :4)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga Hijo---")
cur.close()

print("Carga Complta....")"""

# ------------------------CREACION AFILIACION------------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_AFILIACION.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 1")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_AFILIACION" VALUES (:1, :2, :3, :4)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga Persona---")
cur.close()

print("completed")"""

# ------------------------CREACION BASE LEGAL-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_BASELEGAL.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 5")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_BASELEGAL" VALUES (:1, :2, :3, :4, :5)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga Base Legal---")
cur.close()

print("completed")"""
# ------------------------CREACION CODIGO-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_CODIGO.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 5")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_CODIGO" VALUES (:1, :2, :3, :4, :5, :6)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga Codigo---")
cur.close()

print("completed")"""
# ------------------------CREACION APORTACION-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_APORTACION.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 6")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_APORTACION" VALUES (:1, :2, :3, :4, :5)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga Aportacion---")
cur.close()

print("completed")"""
# ------------------------CREACION EMPRESA-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_EMPRESA.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 5")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_EMPRESA" VALUES (:1, :2, :3, :4, :5, :6, :7)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga EMPRESA---")
cur.close()
print("Carga Completa")"""
# ------------------------CREACION USUARIO----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_USUARIO.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 5")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_USUARIO" VALUES (:1, :2, :3, :4)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga USUARIO---")
cur.close()
print("Carga Completa")"""
# ------------------------CREACION PERFIL-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_PERFIL.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 5")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_PERFIL" VALUES (:1, :2, :3, :4)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga PERFIL---")
cur.close()
print("Carga Completa")"""
# ------------------------CREACION ROL-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_ROL.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 5")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_ROL" VALUES (:1, :2, :3, :4)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga ROL---")
cur.close()
print("Carga Completa")"""
# ------------------------CREACION TRABAJO-----------------------
"""reader = csv.reader(open("C:\ITIN\PROJECT\TB_TRABAJO.csv","r"))
#next(reader) # assumption is your db_table has header
columns = []
for line in reader:
    columns.append(line)
print("read")

cur = con.cursor()
print("Inserting data 5")
dbdata = []
for line in columns:
    line.pop(0)
    dbdata.append(line)
print(dbdata)
dbdata.pop(0)
for line in dbdata:
    insrt_stmt = 'INSERT INTO "TB_TRABAJO" VALUES (:1, :2, :3, :4, :5)'
    cur.execute(insrt_stmt, line)
con.commit()
print("---Carga TRABAJO---")
cur.close()
print("Carga Completa")"""