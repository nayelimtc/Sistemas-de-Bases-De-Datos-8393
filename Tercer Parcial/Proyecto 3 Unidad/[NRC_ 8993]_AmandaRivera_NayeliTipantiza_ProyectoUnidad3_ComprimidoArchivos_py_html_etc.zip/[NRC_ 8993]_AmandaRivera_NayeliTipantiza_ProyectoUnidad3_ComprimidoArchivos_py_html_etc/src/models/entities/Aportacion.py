from flask_login import UserMixin
"""Se crea una instancia para el usuario para tratarle como un objeto en el aplicativo

    Returns:
       genera los objetos para poder establecer el usuario y contraseña
    """ 

class Aportacion(UserMixin):

    def __init__(self, username, fecaportacion, noaportacion, detaportacion,montaportacion) -> None:
        self.username = username
        self.fecaportacion = fecaportacion
        self.noaportacion = noaportacion
        self.detaportacion = detaportacion
        self.montaportacion = montaportacion