from .entities.User import User
from .entities.Aportacion import Aportacion
from .entities.Afiliado import Afiliado

"""Se crear la clase ModelUser donde se va a definir los parámetros necesarios para el login
    en este se definen los campos que va a solicitar el login para ingresar al sistema

    Returns:
        Una vez recorrido las estructuras con el curso se concatena el usuario y contraseña con la base de datos 
    """ 
class ModelUser():


    @classmethod
    def login(self, db, username):
        try:
            cursor = db.cursor()
            sql = """SELECT
                    u.var_nombre_usuario,
                    u.var_contrasenia_usuario,
                    p.var_genero_persona,
                    p.dt_fecha_nac_persona,
                    p.var_provincia_persona,
                    p.var_canton_persona,
                    p.var_tel_persona,
                    f.var_nombre_perfil
                FROM
                    tb_persona p,
                    tb_usuario u,
                    tb_perfil f
                WHERE
                    u.var_id_persona = p.var_id_persona AND
                    f.var_id_usuario = u.var_id_usuario AND 
                    u.var_nombre_usuario = '{}'""".format(username)
            cursor.execute(sql)
            row = cursor.fetchone()
            format_code = '%Y-%m-%d'
            if row != None:
                user = User(row[0], row[1],row[2],row[3].strftime(format_code),row[4],row[5],row[6],row[7])
                return user
            else:
                return None
        except Exception as ex:
            print("EXCEPTION LOGIN")
            raise Exception(ex)

    @classmethod
    def get_by_id(self, db, id):
        try:
            cursor = db.cursor()
            sql = """SELECT VAR_NOMBRE_USUARIO, VAR_CONTRASENIA_USUARIO FROM TB_USUARIO 
                    WHERE VAR_NOMBRE_USUARIO = '{}'""".format(id)
            cursor.execute(sql)
            row = cursor.fetchone()
            print("USUARIO1 ")
            print(row)
            if row != None:
                return User(row[0], row[1])
            else:
                return None
        except Exception as ex:
            print("EXCEPTION GET")
            raise Exception(ex)

    @classmethod
    def get_aportacion(self, db, id):
        try:
            cursor = db.cursor()
            sql = """SELECT
                    u.var_nombre_usuario,
                    a.dt_fecha_aportacion,
                    a.int_no_aportacion,
                    a.var_detalle_aportacion,
                    a.var_monto_aportacion
                FROM
                    tb_trabajo    t,
                    tb_persona    p,
                    tb_aportacion a,
                    tb_usuario    u
                WHERE
                    t.var_id_persona = p.var_id_persona
                    AND t.var_id_aportacion = a.var_id_aportacion
                    AND p.var_id_persona = u.var_id_persona
                    AND u.var_nombre_usuario = '{}'""".format(id)
            cursor.execute(sql)
            records = cursor.fetchall()
            print("USUARIO1 ")
            print(records)
            if records != None:
                list = []
                for row in records:
                    list.append(Aportacion(row[0], row[1],row[2],row[3],row[4]))
                return list
            else:
                return None
        except Exception as ex:
            print("EXCEPTION GET")
            raise Exception(ex)
        
    @classmethod
    def get_afiliados(self, db):
        try:
            cursor = db.cursor()
            sql = """SELECT
                    p.var_nombre_persona,
                    p.var_genero_persona,
                    p.dt_fecha_nac_persona,
                    a.var_nombre_afiliacion,
                    a.var_tipo_afiliacion,
                    a.var_estado_afiliacion,
                    a.var_id_afiliacion
                FROM
                    tb_trabajo t,
                    tb_persona p,
                    tb_afiliacion a
                WHERE
                    a.var_id_afiliacion = t.var_id_afiliacion
                    AND p.var_id_persona = t.var_id_persona"""
            cursor.execute(sql)
            records =  cursor.fetchall()
            print("USUARIO1 ")
            print(records)
            if records != None:
                list = []
                for row in records:   
                    list.append(Afiliado(row[0],row[1],row[2],row[3],row[4],row[5],row[6]))
                return list
            else:
                return None
        except Exception as ex:
            print("EXCEPTION GET")
            raise Exception(ex)
    
    @classmethod
    def get_afiliado_by_id(self, db, nombre):
        try:
            cursor = db.cursor()
            sql = """SELECT
                    p.var_nombre_persona,
                    p.var_genero_persona,
                    p.dt_fecha_nac_persona,
                    a.var_nombre_afiliacion,
                    a.var_tipo_afiliacion,
                    a.var_estado_afiliacion,
                    a.var_id_afiliacion
                FROM
                    tb_trabajo t,
                    tb_persona p,
                    tb_afiliacion a
                WHERE
                    a.var_id_afiliacion = t.var_id_afiliacion
                    AND p.var_id_persona = t.var_id_persona
                    AND p.var_nombre_persona = '{}'""".format(nombre)
            cursor.execute(sql)
            row =  cursor.fetchone()
            print("USUARIO1 ")
            print(row)
            format_code = '%Y-%m-%d'
            if row != None:
                return Afiliado(row[0],row[1],row[2].strftime(format_code),row[3],row[4],row[5],row[6])
            else:
                return None
        except Exception as ex:
            print("EXCEPTION GET")
            raise Exception(ex)
    
    @classmethod
    def update_afiliado(self, db, nomafiliacion,tipafiliacion,estafiliacion,nombre):
        try:
            cursor = db.cursor()
            sql = """SELECT
                    p.var_nombre_persona,
                    p.var_genero_persona,
                    p.dt_fecha_nac_persona,
                    a.var_nombre_afiliacion,
                    a.var_tipo_afiliacion,
                    a.var_estado_afiliacion,
                    a.var_id_afiliacion
                FROM
                    tb_trabajo t,
                    tb_persona p,
                    tb_afiliacion a
                WHERE
                    a.var_id_afiliacion = t.var_id_afiliacion
                    AND p.var_id_persona = t.var_id_persona
                    AND p.var_nombre_persona = '{}'""".format(nombre)
            cursor.execute(sql)
            row =  cursor.fetchone()
            sql1 = """
            UPDATE tb_afiliacion
            SET 
                var_nombre_afiliacion   = '{}',
                var_tipo_afiliacion  = '{}',
                var_estado_afiliacion    = '{}'
            WHERE var_id_afiliacion='{}'
            """.format(nomafiliacion,tipafiliacion,estafiliacion,row[6])
            cursor.execute(sql1)
            db.commit()
            cursor.close()
            return True            
        except Exception as ex:
            print("EXCEPTION PUT")
            raise Exception(ex)