from flask import Flask, render_template, request, redirect, url_for, flash
import oracledb
from models.ModelUser import ModelUser
# Entities:
from models.entities.User import User
from models.entities.Afiliado import Afiliado

app = Flask(__name__)

# csrf = CSRFProtect()
# DB_USER = "system"
# DB_PASSWORD = "system"
# Host = "localhost"
# PORT = 1521
# DNS = "XE"
# db = MySQL(app)
# login_manager_app = LoginManager(app)
p_username = "system"
# pw = getpass.getpass("Ingrese sun contraseñia: ")
pw = "0034"
p_password = pw
p_dns = "localhost/xe"
p_port = "1521"

db = oracledb.connect(user=p_username, password=p_password, dsn=p_dns, port=p_port)

# @login_manager_app.user_loader
# def load_user(id):
#     return ModelUser.get_by_id(db, id)


@app.route('/')
def index():
    return redirect(url_for('home'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Esta es la ruta para realizar el login del aplicativo, se recibira un username y un password

    Returns:
        Si las credenciales ingresadas son correctas se redireccionara al inicio del aplicativo
        caso contrario se detalla el error al usurio ya sea que la contraseña es incorrecta o el usuario no esta registrado
    """    
    if request.method == 'POST':
        username = request.form.get("username")
        password = request.form.get("password")
        logged_user = ModelUser.login(db, username)
        if logged_user != None:
            if logged_user.password == password:
                #return redirect(url_for('ingreso'))
                if logged_user.perfil == "Usuario":
                    return render_template("ingreso.html",result = logged_user)
                else:
                    return render_template("admin.html",result = logged_user)
            else:
                flash("Contraseña Incorrecta...")
                return render_template('auth/login.html')
        else:
            flash("Usuario no registrado...")
            return render_template('auth/login.html')
    else:
        return render_template('auth/login.html')

"""Esta es la ruta para regresar al inicio o login

    Returns:
        Si el usuario cimple su función y preiona el boton de logout este será direccionado al inicio de la página
    """ 
@app.route('/logout')
def logout():
    return redirect(url_for('login'))

@app.route('/home')
def home():
    return render_template('home.html')
@app.route('/tramites')
def tramites():
    return render_template('tramites.html')

@app.route('/servicios')
def servicios():
    return render_template('servicios.html')

@app.route('/contactenos')
def contactenos():
    return render_template('contactenos.html')

@app.route('/baselegal')
def baselegal():
    return render_template('baselegal.html')

@app.route('/ingreso')
def ingreso():
    username = request.args.get('username', None)
    user = ModelUser.login(db, username)
    return render_template('ingreso.html', result=user)

@app.route('/aportacion')
def aportacion():
    username = request.args.get('username', None)
    aportacion = ModelUser.get_aportacion(db, username)
    return render_template('aportacion.html', results = aportacion)

@app.route('/logservicio')
def logservicio():
    return render_template('logservicio.html')

@app.route('/opc')
def opc():
    list = ModelUser.get_afiliados(db)
    return render_template('opc.html', users = list)

@app.route('/gestion')
def gestionGet():
    return render_template('gestion.html')

@app.route('/gestion', methods=['POST'])
def gestion():
    if request.method == 'POST':
        nomafiliacion = request.form['nomafiliacion']
        tipafiliacion = request.form['tipafiliacion']
        estafiliacion = request.form['estafiliacion']
        nombre = request.form['nombre']
        ModelUser.update_afiliado(db,nomafiliacion,tipafiliacion,estafiliacion,nombre)
    return render_template('gestion.html')

@app.route('/buscar', methods=['POST'])
def buscar():
    if request.method == 'POST':
        search = request.form['search']
        user = ModelUser.get_afiliado_by_id(db,search)
    return render_template('gestion.html', result = user )

@app.route('/link')
def link():
    return render_template('https://www.iess.gob.ec/documents/10162/2220562/Ley+Organica+del+Sistema+Nacioanl+de+Contratacion+Publica')






@app.route('/protected')
# @login_required
def protected():
    return "<h1>Esta es una vista protegida, solo para usuarios autenticados.</h1>"

"""Si no la conexión no es la correcta se devolvera un error

    Returns:
        Imprimer el error de 401 en el login
    """ 

def status_401(error):
    return redirect(url_for('login'))

"""Si esta ruta no esta bien definida

    Returns:
        La página no carga y devolvera el mensaje de página no encontrada junto con el error 404
    """ 
def status_404(error):
    return "<h1>Página no encontrada</h1>", 404


if __name__ == '__main__':
    app.register_error_handler(401, status_401)
    app.register_error_handler(404, status_404)
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'
    app.run()
    
from flask import Flask, render_template