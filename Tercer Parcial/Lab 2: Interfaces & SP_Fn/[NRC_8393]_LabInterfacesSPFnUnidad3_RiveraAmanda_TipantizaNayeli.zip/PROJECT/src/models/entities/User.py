from flask_login import UserMixin
"""Se crea una instancia para el usuario para tratarle como un objeto en el aplicativo

    Returns:
       genera los objetos para poder establecer el usuario y contraseña
    """ 

class User(UserMixin):

    def __init__(self, username, password) -> None:
        self.username = username
        self.password = password

