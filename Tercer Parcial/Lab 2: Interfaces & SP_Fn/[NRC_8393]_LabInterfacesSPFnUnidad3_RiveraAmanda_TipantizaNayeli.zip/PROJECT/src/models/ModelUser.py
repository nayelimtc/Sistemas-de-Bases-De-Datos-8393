from .entities.User import User

"""Se crear la clase ModelUser donde se va a definir los parámetros necesarios para el login
    en este se definen los campos que va a solicitar el login para ingresar al sistema

    Returns:
        Una vez recorrido las estructuras con el curso se concatena el usuario y contraseña con la base de datos 
    """ 
class ModelUser():


    @classmethod
    def login(self, db, username):
        try:
            cursor = db.cursor()
            sql = """SELECT VAR_NOMBRE_USUARIO, VAR_CONTRASENIA_USUARIO FROM TB_USUARIO 
                    WHERE VAR_NOMBRE_USUARIO = '{}'""".format(username)
            cursor.execute(sql)
            row = cursor.fetchone()
            print("USUARIO ")
            print(row)
            if row != None:
                user = User(row[0], row[1])
                return user
            else:
                return None
        except Exception as ex:
            print("EXCEPTION LOGIN")
            raise Exception(ex)

    @classmethod
    def get_by_id(self, db, id):
        try:
            cursor = db.cursor()
            # sql = "SELECT username, fullname FROM user WHERE id = {}".format(id)
            sql = """SELECT VAR_NOMBRE_USUARIO, VAR_CONTRASENIA_USUARIO FROM TB_USUARIO 
                    WHERE VAR_NOMBRE_USUARIO = '{}'""".format(id)
            cursor.execute(sql)
            row = cursor.fetchone()
            print("USUARIO1 ")
            print(row)
            if row != None:
                return User(row[0], row[1])
            else:
                return None
        except Exception as ex:
            print("EXCEPTION GET")
            raise Exception(ex)
